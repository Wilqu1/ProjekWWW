<?php require 'config.php'; ?>
<?php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$pdo->query("DELETE FROM posts WHERE user_id IN (SELECT id FROM users WHERE is_banned = 1)");

$stmt = $pdo->query("
    SELECT posts.*, users.username, users.profile_pic, users.id AS user_id 
    FROM posts 
    JOIN users ON posts.user_id = users.id 
    ORDER BY posts.created_at DESC
");
$posts = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feed</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header>
        <nav>
            <a href="add_post.php">➕ Dodaj post</a> | 
            <a href="logout.php">🚪 Wyloguj</a> | 
            <a href="edit_profile.php">👤 Edytuj profil</a>
            <?php if ($_SESSION['is_admin']): ?>
                <a href="admin_panel.php">👑 Panel admina</a>
            <?php endif; ?>
        </nav>
    </header>

    <div class="search-bar">
        <form action="search_users.php" method="GET">
            <input type="text" name="query" placeholder="Szukaj użytkowników..." required>
            <button type="submit">Szukaj</button>
        </form>
    </div>

    <div class="feed">
        <?php foreach ($posts as $post): ?>
            <div class="post">
                <div class="post-header">
                    <img src="<?= htmlspecialchars($post['profile_pic'] ?: 'uploads/default.jpg') ?>" class="avatar" />
                    <strong>
                        <a href="user_profile.php?user_id=<?= htmlspecialchars($post['user_id']) ?>">
                            <?= htmlspecialchars($post['username']) ?>
                        </a>
                    </strong>
                    <?php if ($post['user_id'] !== $_SESSION['user_id']): ?>
                        <?php
                        $stmt = $pdo->prepare("SELECT * FROM follows WHERE follower_id = ? AND followed_id = ?");
                        $stmt->execute([$_SESSION['user_id'], $post['user_id']]);
                        $isFollowing = $stmt->rowCount() > 0;
                        ?>
                        <span class="follow-status">
                            <?= $isFollowing ? 'Following' : 'Not Following' ?>
                        </span>
                    <?php endif; ?>
                </div>

                <?php if ($post['image_path']): ?>
                    <img src="<?= htmlspecialchars($post['image_path']) ?>" class="post-img" />
                <?php endif; ?>
                <p><?= nl2br(htmlspecialchars($post['caption'])) ?></p>

                <?php
                    $likes = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE post_id = ?");
                    $likes->execute([$post['id']]);
                    $likeCount = $likes->fetchColumn();

                    $isLiked = $pdo->prepare("SELECT * FROM likes WHERE post_id = ? AND user_id = ?");
                    $isLiked->execute([$post['id'], $_SESSION['user_id']]);
                    $liked = $isLiked->rowCount() > 0;
                ?>
                <button class="like-button <?= $liked ? 'liked' : '' ?>" data-post-id="<?= $post['id'] ?>">
                    <?= $liked ? '❤️' : '🤍' ?> <?= $likeCount ?>
                </button>

                <div class="comments" id="comments-<?= $post['id'] ?>"></div>

                <form class="comment-form" data-id="<?= $post['id'] ?>">
                    <input type="text" name="comment" placeholder="Dodaj komentarz..." required>
                    <button type="submit">💬</button>
                </form>

                <?php if ($post['user_id'] == $_SESSION['user_id'] || $_SESSION['is_admin']): ?>
                    <a href="delete_post.php?id=<?= $post['id'] ?>">🗑️ Usuń</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

        
    <script src="assets/js/main.js"></script>
</body>
</html>
