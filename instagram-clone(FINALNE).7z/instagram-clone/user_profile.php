<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$logged_in_user_id = $_SESSION['user_id'];
$viewed_user_id = $_GET['user_id'] ?? null;

if (!$viewed_user_id) {
    echo "Nie znaleziono użytkownika.";
    exit;
}

// Pobierz dane użytkownika
$stmt = $pdo->prepare("SELECT username, profile_pic FROM users WHERE id = ?");
$stmt->execute([$viewed_user_id]);
$user = $stmt->fetch();

if (!$user) {
    echo "Nie znaleziono użytkownika.";
    exit;
}

// Sprawdź, czy zalogowany użytkownik obserwuje wyświetlanego użytkownika
$stmt = $pdo->prepare("SELECT COUNT(*) FROM follows WHERE follower_id = ? AND followed_id = ?");
$stmt->execute([$logged_in_user_id, $viewed_user_id]);
$is_following = $stmt->fetchColumn() > 0;

// Pobierz listę osób, które użytkownik obserwuje
$stmt = $pdo->prepare("SELECT u.id, u.username, u.profile_pic FROM follows f JOIN users u ON f.followed_id = u.id WHERE f.follower_id = ?");
$stmt->execute([$viewed_user_id]);
$following = $stmt->fetchAll();

// Pobierz listę obserwujących
$stmt = $pdo->prepare("SELECT u.id, u.username, u.profile_pic FROM follows f JOIN users u ON f.follower_id = u.id WHERE f.followed_id = ?");
$stmt->execute([$viewed_user_id]);
$followers = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil użytkownika</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .profile-container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-right: 20px;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
        }
        h1, h2 {
            margin-top: 0;
        }
        ul {
            list-style-type: none;
            padding-left: 0;
        }
        li {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .avatar-small {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }</style>
</head>
<body>
    <device class="profile-container">
        <a href="feed.php" class="btn">← Powrót</a>
        <div class="profile-header">
            <img src="<?= htmlspecialchars($user['profile_pic']) ?>" alt="Profilowe" class="avatar">
            <h1><?= htmlspecialchars($user['username']) ?></h1>
            <?php if ($logged_in_user_id !== $viewed_user_id): ?>
                <form method="post" action="follow.php">
                    <input type="hidden" name="followed_id" value="<?= $viewed_user_id ?>">
                    <input type="hidden" name="action" value="<?= $is_following ? 'unfollow' : 'follow' ?>">
                    <button type="submit" class="btn"><?= $is_following ? 'Unfollow' : 'Follow' ?></button>
                </form>
            <?php endif; ?>
        </div>

        <h2>Obserwuje:</h2>
        <ul>
            <?php foreach ($following as $followed): ?>
                <li>
                    <img src="<?= htmlspecialchars($followed['profile_pic']) ?>" class="avatar-small">
                    <a href="user_profile.php?user_id=<?= $followed['id'] ?>"><?= htmlspecialchars($followed['username']) ?></a>
                </li>
            <?php endforeach; ?>
        </ul>

        <h2>Obserwujący:</h2>
        <ul>
            <?php foreach ($followers as $follower): ?>
                <li>
                    <img src="<?= htmlspecialchars($follower['profile_pic']) ?>" class="avatar-small">
                    <a href="user_profile.php?user_id=<?= $follower['id'] ?>"><?= htmlspecialchars($follower['username']) ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
