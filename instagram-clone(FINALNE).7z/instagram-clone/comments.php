<?php
require 'config.php';

$post_id = $_GET['post_id'] ?? null;
if (!$post_id) {
    http_response_code(400);
    exit('Post ID is required');
}

try {
    $stmt = $pdo->prepare("
        SELECT comments.*, users.username 
        FROM comments 
        JOIN users ON comments.user_id = users.id 
        WHERE post_id = ? 
        ORDER BY comments.parent_comment_id ASC, comments.created_at ASC
    ");
    $stmt->execute([$post_id]);
    $comments = $stmt->fetchAll();

    foreach ($comments as $c) {
        echo "<div class='comment'>";
        echo "<p><strong><a href='user_profile.php?user_id=" . htmlspecialchars($c['user_id']) . "'>" . htmlspecialchars($c['username']) . "</a>:</strong> " . nl2br(htmlspecialchars($c['content'])) . "</p>";
        echo "</div>";
    }

    if (isset($_GET['parent_comment_id'])) {
        $parent_comment_id = $_GET['parent_comment_id'];

        $stmt = $pdo->prepare("
            SELECT comments.*, users.username 
            FROM comments 
            JOIN users ON comments.user_id = users.id 
            WHERE parent_comment_id = ? 
            ORDER BY comments.created_at ASC
        ");
        $stmt->execute([$parent_comment_id]);
        $replies = $stmt->fetchAll();

        foreach ($replies as $r) {
            echo "<div class='reply'>";
            echo "<p><strong><a href='user_profile.php?user_id=" . htmlspecialchars($r['user_id']) . "'>" . htmlspecialchars($r['username']) . "</a>:</strong> " . nl2br(htmlspecialchars($r['content'])) . "</p>";
            echo "</div>";
        }
    }
} catch (PDOException $e) {
    http_response_code(500);
    exit('Błąd przy pobieraniu komentarzy');
}
