<?php require 'config.php'; ?>

<?php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$post_id = $_GET['id'] ?? null;

$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->execute([$post_id]);
$post = $stmt->fetch();

if (!$post) {
    echo "Post nie istnieje.";
    exit;
}

if ($post['user_id'] != $_SESSION['user_id'] && !$_SESSION['is_admin']) {
    echo "Nie masz uprawnień.";
    exit;
}

if ($post['image_path'] && file_exists($post['image_path'])) {
    unlink($post['image_path']);
}

$stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
$stmt->execute([$post_id]);

header("Location: feed.php");
exit;
