document.addEventListener("DOMContentLoaded", function () {
    function initializeCommentForm(form) {
        const newForm = form.cloneNode(true); // usuwa stare eventy
        form.parentNode.replaceChild(newForm, form); // zastępuje form nowym

        const postId = newForm.dataset.id;

        newForm.addEventListener('submit', e => {
            e.preventDefault();

            const input = newForm.querySelector('input[name="comment"], textarea[name="comment"]');
            const content = input.value.trim();

            if (!content) {
                alert('Komentarz nie może być pusty!');
                return;
            }

            fetch('comment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `post_id=${postId}&content=${encodeURIComponent(content)}`
            })
            .then(res => {
                if (!res.ok) throw new Error('Błąd podczas dodawania komentarza');
                return res.text();
            })
            .then(() => {
                input.value = '';
                loadComments(postId);
            })
            .catch(err => {
                console.error('Błąd podczas dodawania komentarza:', err);
                alert('Nie udało się dodać komentarza. Spróbuj ponownie.');
            });
        });

        return newForm;
    }

    function loadComments(postId) {
        const container = document.getElementById('comments-' + postId);
        if (!container) return;

        fetch('comments.php?post_id=' + postId)
            .then(res => res.text())
            .then(html => {
                container.innerHTML = html;

                // Po załadowaniu komentarzy ponownie znajdź formularz
                const newForm = container.closest('.post').querySelector('.comment-form');
                if (newForm) {
                    initializeCommentForm(newForm);
                }
            })
            .catch(err => {
                console.error('Błąd podczas ładowania komentarzy:', err);
            });
    }

    // Inicjalizacja formularzy komentarzy
    document.querySelectorAll('.comment-form').forEach(initializeCommentForm);

    // Obsługa lajków
    document.querySelectorAll('.like-button').forEach(button => {
        button.addEventListener('click', () => {
            const postId = button.dataset.postId;

            fetch('like.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `post_id=${postId}`
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'liked') {
                    button.classList.add('liked');
                    button.innerHTML = `❤️ ${data.likeCount}`;
                } else if (data.status === 'unliked') {
                    button.classList.remove('liked');
                    button.innerHTML = `🤍 ${data.likeCount}`;
                }
            })
            .catch(err => {
                console.error('Błąd przy fetchu lajka:', err);
            });
        });
    });
});
