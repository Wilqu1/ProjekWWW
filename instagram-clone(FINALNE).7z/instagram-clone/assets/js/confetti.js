// Confetti animation logic
(function() {
    const confettiContainer = document.createElement('div');
    confettiContainer.className = 'confetti';
    document.body.appendChild(confettiContainer);

    function createConfettiPiece() {
        const piece = document.createElement('div');
        piece.style.position = 'absolute';
        piece.style.width = '10px';
        piece.style.height = '10px';
        piece.style.backgroundColor = `hsl(${Math.random() * 360}, 100%, 50%)`;
        piece.style.top = '-10px';
        piece.style.left = `${Math.random() * 100}%`;
        piece.style.opacity = Math.random();
        piece.style.transform = `rotate(${Math.random() * 360}deg)`;
        confettiContainer.appendChild(piece);

        const animationDuration = Math.random() * 3 + 2;
        piece.style.transition = `transform ${animationDuration}s ease-out, top ${animationDuration}s ease-out`;

        setTimeout(() => {
            piece.style.transform = `translateY(${window.innerHeight}px) rotate(${Math.random() * 360}deg)`;
            piece.style.top = `${window.innerHeight}px`;
        }, 0);

        setTimeout(() => {
            confettiContainer.removeChild(piece);
        }, animationDuration * 1000);
    }

    function launchConfetti() {
        for (let i = 0; i < 100; i++) {
            setTimeout(createConfettiPiece, i * 20);
        }
    }

    launchConfetti();
})();