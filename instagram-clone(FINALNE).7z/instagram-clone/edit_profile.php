<?php require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $profilePic = $user['profile_pic'];

    if (!empty($_FILES['profile_pic']['name'])) {
        $fileName = time() . "_" . basename($_FILES["profile_pic"]["name"]);
        $targetFile = "uploads/" . $fileName;
        if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFile)) {
            $profilePic = $targetFile;
        }
    }

    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, profile_pic = ? WHERE id = ?");
    $stmt->execute([$username, $email, $profilePic, $user_id]);

    $_SESSION['username'] = $username;
    header("Location: feed.php");
    exit;
}

$stmt = $pdo->prepare("SELECT u.id, u.username, u.profile_pic FROM follows f JOIN users u ON f.followed_id = u.id WHERE f.follower_id = ?");
$stmt->execute([$user_id]);
$followedAccounts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edytuj profil</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <h2>📝 Edytuj swój profil</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Login:</label><br>
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>

        <label>Nowe zdjęcie profilowe:</label><br>
        <input type="file" name="profile_pic" accept="image/*"><br><br>

        <button type="submit">Zapisz zmiany</button>
    </form>

    <h3>Konta, które obserwujesz:</h3>
    <ul>
    <?php foreach ($followedAccounts as $account): ?>
        <li>
            <img src="<?= htmlspecialchars($account['profile_pic'] ?: 'uploads/default.jpg') ?>" class="avatar" alt="Profile Picture" />
            <?= htmlspecialchars($account['username']) ?>
            <button class="unfollow-btn" data-id="<?= $account['id'] ?>">Unfollow</button>
        </li>
    <?php endforeach; ?>
    </ul>

    <script>
    document.querySelectorAll('.unfollow-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const userId = btn.dataset.id;

            fetch('follow.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'followed_id=' + userId + '&action=unfollow'
            })
            .then(res => res.text())
            .then(response => {
                if (response === 'Unfollowed') {
                    btn.parentElement.remove(); // Remove the user from the list
                }
            });
        });
    });
    </script>
</body>
</html>
