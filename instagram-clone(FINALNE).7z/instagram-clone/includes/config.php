<?php
$conn = new mysqli('localhost', 'root', '', 'insta_clone');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Usunięto automatyczne usuwanie postów zbanowanych użytkowników
// Usuwanie postów przeniesiono do toggle_ban.php
?>