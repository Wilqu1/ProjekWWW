<?php header('Location: login.php'); exit; ?>
<script src="assets/js/main.js"></script>