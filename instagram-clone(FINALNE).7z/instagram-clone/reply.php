<?php require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment_id = $_POST['comment_id'] ?? null;
    $post_id = $_POST['post_id'] ?? null;
    $user_id = $_SESSION['user_id'] ?? null;
    $content = trim($_POST['content'] ?? '');

    if (!$user_id || !$post_id || !$comment_id || $content === '') {
        http_response_code(400);
        exit('Invalid input');
    }

    $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, content, parent_comment_id) VALUES (?, ?, ?, ?)");
    $stmt->execute([$post_id, $user_id, $content, $comment_id]);

    header("Location: feed.php#comments-" . $post_id);
    exit;
}

$comment_id = $_GET['comment_id'];
$post_id = $_GET['post_id'];
?>

<form method="POST" action="reply.php">
    <input type="hidden" name="comment_id" value="<?php echo htmlspecialchars($comment_id); ?>">
    <input type="hidden" name="post_id" value="<?php echo htmlspecialchars($post_id); ?>">
    <textarea name="content" placeholder="Write your reply..." required></textarea>
    <button type="submit">Reply</button>
    <a href="feed.php#comments-<?php echo htmlspecialchars($post_id); ?>" class="cancel-btn">Cancel</a>
</form>