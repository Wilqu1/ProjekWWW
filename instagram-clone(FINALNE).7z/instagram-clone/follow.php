<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo 'error:Nie jesteś zalogowany.';
    exit;
}

$follower_id = $_SESSION['user_id'];
$followed_id = filter_input(INPUT_POST, 'followed_id', FILTER_VALIDATE_INT);
$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);

if (!$followed_id || !in_array($action, ['follow', 'unfollow'])) {
    echo 'error:Nieprawidłowe dane.';
    exit;
}

if ($follower_id === $followed_id) {
    echo 'error:Nie możesz obserwować samego siebie.';
    exit;
}

try {
    if ($action === 'follow') {
        $stmt = $pdo->prepare("INSERT IGNORE INTO follows (follower_id, followed_id) VALUES (?, ?)");
        $stmt->execute([$follower_id, $followed_id]);
    } elseif ($action === 'unfollow') {
        $stmt = $pdo->prepare("DELETE FROM follows WHERE follower_id = ? AND followed_id = ?");
        $stmt->execute([$follower_id, $followed_id]);
    }

    // Pobierz zaktualizowaną liczbę followersów
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM follows WHERE followed_id = ?");
    $countStmt->execute([$followed_id]);
    $followersCount = $countStmt->fetchColumn();

    $statusText = $action === 'follow' ? 'Followed' : 'Unfollowed';
    echo "success:$statusText:$followersCount";
} catch (PDOException $e) {
    error_log("Błąd follow/unfollow: " . $e->getMessage());
    echo 'error:Wystąpił błąd serwera.';
}
header("Location: user_profile.php?user_id=$followed_id");
exit;
