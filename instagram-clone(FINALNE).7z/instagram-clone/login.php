<?php require 'config.php'; ?>

<link rel="stylesheet" href="assets/css/style.css">

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['is_banned']) {
            echo "<div class='banned-message'>Twoje konto zostało zbanowane.</div>";
            echo "<script src='assets/js/confetti.js'></script>";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['is_admin'] = $user['is_admin'];
            header("Location: feed.php");
            exit;
        }
    } else {
        echo "Nieprawidłowy login lub hasło.";
    }
}
?>

<div class="platform-title">PLATFORMA SPOŁECZNOŚIOWA</div>

<div class="login-container">
    <form method="POST">
        <input type="text" name="username" placeholder="Nazwa użytkownika" required><br>
        <input type="password" name="password" placeholder="Hasło" required><br>
        <button type="submit">Zaloguj się</button>
        <button type="button" onclick="window.location.href='register.php'">Zarejestruj</button>
    </form>
</div>
