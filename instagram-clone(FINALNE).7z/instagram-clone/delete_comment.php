<?php require 'config.php';

if (!isset($_SESSION['user_id'])) exit;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment_id = $_POST['comment_id'];
    $user_id = $_SESSION['user_id'];
    $is_admin = $_SESSION['is_admin'] ?? false;

    // Check if the user is the owner of the comment or an admin
    $stmt = $pdo->prepare("SELECT user_id FROM comments WHERE id = ?");
    $stmt->execute([$comment_id]);
    $comment = $stmt->fetch();

    if ($comment && ($comment['user_id'] == $user_id || $is_admin)) {
        $deleteStmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
        $deleteStmt->execute([$comment_id]);
        echo "Komentarz został usunięty.";
    } else {
        echo "Nie masz uprawnień do usunięcia tego komentarza.";
    }
} else {
    echo "Nieprawidłowe żądanie.";
}