<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$query = isset($_GET['query']) ? trim($_GET['query']) : '';
$users = [];

if ($query !== '') {
    $stmt = $pdo->prepare("SELECT id, username, profile_pic, is_banned FROM users WHERE username LIKE ? LIMIT 10");
    $stmt->execute(['%' . $query . '%']);
    $users = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wyniki wyszukiwania</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header>
        <nav>
            <a href="feed.php">⬅️ Powrót do feedu</a>
        </nav>
    </header>

    <h1>Wyniki wyszukiwania dla: "<?= htmlspecialchars($query) ?>"</h1>

    <div class="user-results">
        <?php if (count($users) > 0): ?>
            <ul>
                <?php foreach ($users as $user): ?>
                    <li>
                        <img src="<?= htmlspecialchars($user['profile_pic'] ?: 'uploads/default.jpg') ?>" class="avatar" alt="Profile Picture">
                        <a href="user_profile.php?user_id=<?= htmlspecialchars($user['id']) ?>">
                            <?= htmlspecialchars($user['username']) ?>
                        </a>
                        <?php if ($user['is_banned']): ?>
                            <span class="banned-label">BAN</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Brak wyników.</p>
        <?php endif; ?>
    </div>
</body>
</html>