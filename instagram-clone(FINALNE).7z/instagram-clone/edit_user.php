<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    die("Brak dostępu");
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) die("Nie znaleziono użytkownika.");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $profilePic = $user['profile_pic'];

    if (!empty($_FILES['profile_pic']['name'])) {
        $fileName = time() . "_" . basename($_FILES["profile_pic"]["name"]);
        $targetFile = "uploads/" . $fileName;
        if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFile)) {
            $profilePic = $targetFile;
        }
    }

    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, profile_pic = ? WHERE id = ?");
    $stmt->execute([$username, $email, $profilePic, $id]);

    header("Location: admin_panel.php");
    exit;
}
?>

<h2>Edytuj użytkownika</h2>
<form method="POST" enctype="multipart/form-data">
    <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required><br>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br>
    <label>Nowy avatar: <input type="file" name="profile_pic" accept="image/*"></label><br>
    <button type="submit">Zapisz</button>
</form>
