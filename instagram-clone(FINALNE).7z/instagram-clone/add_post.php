<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $caption = trim($_POST['caption']);
    $imagePath = null;

    if (!empty($_FILES['image']['name'])) {
        $targetDir = "uploads/";
        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $fileName;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        if (in_array($imageFileType, ['jpg', 'jpeg', 'png'])) {
            if ($_FILES["image"]["size"] <= 5 * 1024 * 1024) {
                if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                    $imagePath = $targetFile;
                } else {
                    echo "Błąd przesyłania pliku.";
                    exit;
                }
            } else {
                echo "Plik za duży!";
                exit;
            }
        } else {
            echo "Nieobsługiwany format!";
            exit;
        }
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO posts (user_id, image_path, caption) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $imagePath, $caption]);

        header("Location: feed.php");
        exit;
    } catch (PDOException $e) {
        error_log("Błąd dodawania posta: " . $e->getMessage());
        echo "Wystąpił błąd podczas dodawania posta.";
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Dodaj post</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<form class="upload-post" method="POST" enctype="multipart/form-data">

    <textarea name="caption" placeholder="Dodaj opis..."></textarea><br>
    <input type="file" name="image" accept="image/*"><br>
    <button type="submit" class="btn">Dodaj post</button>
    <a href="feed.php" class="btn cancel-btn">Anuluj</a>
</form>
