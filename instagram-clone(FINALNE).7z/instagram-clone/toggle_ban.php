<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    die("Brak dostępu");
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT is_banned FROM users WHERE id = ?");
$stmt->execute([$id]);
$u = $stmt->fetch();

if ($u) {
    $newStatus = $u['is_banned'] ? 0 : 1;
    $pdo->prepare("UPDATE users SET is_banned = ? WHERE id = ?")->execute([$newStatus, $id]);
}

// Usuwanie postów użytkownika w momencie banowania
if ($u && $newStatus === 1) { // Jeśli użytkownik został zbanowany
    $stmt = $pdo->prepare("DELETE FROM posts WHERE user_id = ?");
    $stmt->execute([$id]);
}

header("Location: admin_panel.php");
exit;
