<?php
session_start();
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit('Access denied');
}

$content = trim($_POST['content'] ?? '');
$post_id = filter_input(INPUT_POST, 'post_id', FILTER_VALIDATE_INT);
$user_id = $_SESSION['user_id'];

if (!$post_id || $content === '') {
    http_response_code(400);
    exit('Invalid input');
}

try {
    $stmt = $pdo->prepare("INSERT INTO comments (user_id, post_id, content) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $post_id, htmlspecialchars($content, ENT_QUOTES, 'UTF-8')]);

    http_response_code(200);
    exit('Comment added');
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    http_response_code(500);
    exit('An error occurred while adding the comment');
}
