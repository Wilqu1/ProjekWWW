<?php require 'config.php';

if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    die("Brak dostępu");
}

$stmt = $pdo->query("SELECT * FROM users");
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administracyjny</title>
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Dodanie stylów -->
</head>
<body>
    <div class="admin-panel">
        <h2>👥 Lista użytkowników</h2>
        <a href="feed.php" class="btn">Powrót do Feed</a> <!-- Dodanie przycisku -->

        <table class="user-table" border="1" cellpadding="5">
            <tr>
                <th>ID</th><th>Avatar</th><th>Login</th><th>Email</th>
                <th>Admin</th><th>Zbanowany</th><th>Akcje</th>
            </tr>

            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><img src="<?= $u['profile_pic'] ?>" width="40" height="40" style="border-radius:50%"></td>
                <td><?= htmlspecialchars($u['username']) ?></td>
                <td><?= htmlspecialchars($u['email']) ?></td>
                <td><?= $u['is_admin'] ? '✔️' : '—' ?></td>
                <td><?= $u['is_banned'] ? '🚫' : '✅' ?></td>
                <td>
                    <a href="edit_user.php?id=<?= $u['id'] ?>">✏️ Edytuj</a>
                    <?php if (!$u['is_admin']): ?>
                        | <a href="toggle_ban.php?id=<?= $u['id'] ?>">
                            <?= $u['is_banned'] ? '✅ Odbanuj' : '🚫 Zbanuj' ?>
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>
