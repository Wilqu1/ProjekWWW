<?php
session_start();
ob_clean();
header('Content-Type: application/json');

require 'config.php';
// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['status' => 'unauthorized']);
    exit;
}

// Sprawdź, czy przesłano post_id
if (!isset($_POST['post_id']) || empty($_POST['post_id'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Brak ID posta']);
    exit;
}

$post_id = $_POST['post_id'];
$user_id = $_SESSION['user_id'];

try {
    // Czy użytkownik już polubił post?
    $stmt = $pdo->prepare("SELECT * FROM likes WHERE post_id = ? AND user_id = ?");
    $stmt->execute([$post_id, $user_id]);

    if ($stmt->rowCount() > 0) {
        // Usuń lajk
        $pdo->prepare("DELETE FROM likes WHERE post_id = ? AND user_id = ?")->execute([$post_id, $user_id]);
        $status = 'unliked';
    } else {
        // Dodaj lajk
        $pdo->prepare("INSERT INTO likes (post_id, user_id) VALUES (?, ?)")->execute([$post_id, $user_id]);
        $status = 'liked';
    }

    // Zlicz wszystkie lajki po zmianie
    $likeCountStmt = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE post_id = ?");
    $likeCountStmt->execute([$post_id]);
    $likeCount = $likeCountStmt->fetchColumn();

    echo json_encode([
        'status' => $status,
        'likeCount' => (int)$likeCount
    ]);
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Błąd serwera']);
}
